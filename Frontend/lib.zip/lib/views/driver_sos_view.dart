import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:hoppo/providers/driver_provider.dart';
import 'package:hoppo/widgets/hoppo_theme.dart';

class DriverSosView extends StatefulWidget {
  const DriverSosView({super.key});

  @override
  State<DriverSosView> createState() => _DriverSosViewState();
}

class _DriverSosViewState extends State<DriverSosView>
    with TickerProviderStateMixin {
  // ── Hold-to-activate state ──────────────────────────────────────────
  bool _holding = false;
  bool _sosActive = false;
  double _holdProgress = 0.0;
  Timer? _holdTimer;
  Timer? _pulseTimer;

  // ── Post-activation cancel window (10s) ────────────────────────────
  int _cancelCountdown = 10;
  Timer? _cancelTimer;

  // ── Escalation step tracking ────────────────────────────────────────
  int _escalationStep = 0; // 0=idle, 1=admin, 2=school, 3=contacts, 4=112
  Timer? _escalationTimer;

  // ── Animation ──────────────────────────────────────────────────────
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;
  late AnimationController _ringController;
  late Animation<double> _ringAnim;

  // ── Escalation chain config ─────────────────────────────────────────
  final List<_EscalationStep> _steps = const [
    _EscalationStep(
      icon: Icons.headset_mic_rounded,
      label: 'Hoppo Admin',
      sublabel: 'Control room notified',
      color: kRed,
    ),
    _EscalationStep(
      icon: Icons.school_rounded,
      label: 'School / HR Admin',
      sublabel: 'School contact alerted',
      color: kRed,
    ),
    _EscalationStep(
      icon: Icons.contacts_rounded,
      label: 'Emergency Contacts',
      sublabel: 'Up to 3 personal contacts called',
      color: kRed,
    ),
    _EscalationStep(
      icon: Icons.local_police_rounded,
      label: 'Police Helpline 112',
      sublabel: 'Authorities alerted',
      color: kRed,
    ),
  ];

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.12).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    _ringAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ringController, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    _cancelTimer?.cancel();
    _escalationTimer?.cancel();
    _pulseController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  // ── Hold gesture handlers ───────────────────────────────────────────

  void _onHoldStart() {
    if (_sosActive) return;
    setState(() {
      _holding = true;
      _holdProgress = 0;
    });
    HapticFeedback.mediumImpact();

    const tickMs = 30;
    const totalMs = 3000;
    int elapsed = 0;

    _holdTimer = Timer.periodic(const Duration(milliseconds: tickMs), (t) {
      elapsed += tickMs;
      setState(() => _holdProgress = elapsed / totalMs);
      if (elapsed >= totalMs) {
        t.cancel();
        _activateSOS();
      }
    });
  }

  void _onHoldEnd() {
    if (_sosActive) return;
    _holdTimer?.cancel();
    setState(() {
      _holding = false;
      _holdProgress = 0;
    });
  }

  // ── SOS activation ──────────────────────────────────────────────────

  void _activateSOS() {
    HapticFeedback.heavyImpact();
    setState(() {
      _sosActive = true;
      _holding = false;
      _holdProgress = 0;
      _cancelCountdown = 10;
      _escalationStep = 0;
    });

    _ringController.repeat();
    _pulseController.repeat(reverse: true);

    // Cancel window countdown
    _cancelTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() => _cancelCountdown--);
      if (_cancelCountdown <= 0) {
        t.cancel();
        _beginEscalation();
      }
    });

    // Push SOS to Firebase
    final provider = context.read<DriverProvider>();
    provider.triggerSos();
  }

  void _beginEscalation() {
    setState(() => _escalationStep = 1);
    // Advance step every 15s to simulate escalation chain
    _escalationTimer =
        Timer.periodic(const Duration(seconds: 15), (t) {
      if (_escalationStep >= _steps.length) {
        t.cancel();
        return;
      }
      setState(() => _escalationStep++);
      HapticFeedback.heavyImpact();
    });
  }

  void _cancelSOS() {
    _cancelTimer?.cancel();
    _escalationTimer?.cancel();
    _ringController.stop();
    _ringController.reset();

    setState(() {
      _sosActive = false;
      _holding = false;
      _holdProgress = 0;
      _escalationStep = 0;
      _cancelCountdown = 10;
    });

    final provider = context.read<DriverProvider>();
    provider.cancelSos();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('SOS cancelled.',
            style: TextStyle(fontFamily: 'Outfit')),
        backgroundColor: kGreen,
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  // ── Build ───────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _sosActive ? const Color(0xFF1A0000) : kBackground,
      body: SafeArea(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 400),
          child: _sosActive ? _buildActiveSOSView() : _buildIdleView(),
        ),
      ),
    );
  }

  // ── IDLE: hold-to-activate ──────────────────────────────────────────

  Widget _buildIdleView() {
    return Column(
      key: const ValueKey('idle'),
      children: [
        _buildHeader(),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Emergency SOS',
                style: TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: kTextDark,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Hold the button for 3 seconds to activate',
                style: TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 13,
                  color: kTextMid,
                ),
              ),
              const SizedBox(height: 48),

              // ── Hold button ───────────────────────────────────────
              GestureDetector(
                onTapDown: (_) => _onHoldStart(),
                onTapUp: (_) => _onHoldEnd(),
                onTapCancel: _onHoldEnd,
                child: AnimatedBuilder(
                  animation: _pulseController,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _holding ? 1.0 : _pulseAnim.value,
                      child: child,
                    );
                  },
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Progress ring
                      SizedBox(
                        width: 160,
                        height: 160,
                        child: CircularProgressIndicator(
                          value: _holdProgress,
                          strokeWidth: 6,
                          backgroundColor: kRedLight,
                          valueColor:
                              const AlwaysStoppedAnimation<Color>(kRed),
                        ),
                      ),
                      // Button body
                      Container(
                        width: 140,
                        height: 140,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _holding ? kRed : kRedLight,
                          boxShadow: [
                            BoxShadow(
                              color: kRed.withOpacity(
                                  _holding ? 0.5 : 0.2),
                              blurRadius: 24,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.sos_rounded,
                              size: 48,
                              color: _holding
                                  ? Colors.white
                                  : kRed,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _holding ? 'Hold...' : 'SOS',
                              style: TextStyle(
                                fontFamily: 'Outfit',
                                fontWeight: FontWeight.w800,
                                fontSize: 18,
                                color: _holding
                                    ? Colors.white
                                    : kRed,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 56),

              // ── Escalation chain preview ──────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ESCALATION CHAIN',
                      style: TextStyle(
                        fontFamily: 'Outfit',
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: kTextMid,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ..._steps.asMap().entries.map((e) =>
                        _buildChainPreviewRow(e.key, e.value)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildChainPreviewRow(int index, _EscalationStep step) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: kRedLight,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Text(
                '${index + 1}',
                style: const TextStyle(
                  fontFamily: 'Outfit',
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                  color: kRed,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Icon(step.icon, size: 18, color: kTextMid),
          const SizedBox(width: 8),
          Text(
            step.label,
            style: const TextStyle(
              fontFamily: 'Outfit',
              fontWeight: FontWeight.w600,
              fontSize: 13,
              color: kTextDark,
            ),
          ),
        ],
      ),
    );
  }

  // ── ACTIVE SOS view ─────────────────────────────────────────────────

  Widget _buildActiveSOSView() {
    return Column(
      key: const ValueKey('active'),
      children: [
        _buildActiveHeader(),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // Pulsing ring + SOS indicator
                _buildPulsingRing(),
                const SizedBox(height: 32),

                // Cancel window or escalation info
                if (_cancelCountdown > 0)
                  _buildCancelWindow()
                else
                  _buildEscalationStatus(),

                const SizedBox(height: 24),

                // Escalation steps list
                _buildEscalationList(),

                const SizedBox(height: 32),

                // Cancel button
                GestureDetector(
                  onTap: _cancelCountdown > 0 ? _cancelSOS : null,
                  child: AnimatedOpacity(
                    duration: const Duration(milliseconds: 300),
                    opacity: _cancelCountdown > 0 ? 1.0 : 0.3,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.3),
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        _cancelCountdown > 0
                            ? 'Cancel SOS  ($_cancelCountdown s)'
                            : 'SOS Active — Cannot Cancel',
                        style: TextStyle(
                          fontFamily: 'Outfit',
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                          color: _cancelCountdown > 0
                              ? Colors.white
                              : Colors.white38,
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  'Keep the app open. Hoppo admin is monitoring your location.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 12,
                    color: Colors.white.withOpacity(0.5),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPulsingRing() {
    return AnimatedBuilder(
      animation: _ringAnim,
      builder: (context, child) {
        return Stack(
          alignment: Alignment.center,
          children: [
            // Expanding ring 1
            Container(
              width: 140 + (80 * _ringAnim.value),
              height: 140 + (80 * _ringAnim.value),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kRed.withOpacity(
                    0.15 * (1 - _ringAnim.value)),
              ),
            ),
            // Core pulsing button
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, c) =>
                  Transform.scale(scale: _pulseAnim.value, child: c),
              child: Container(
                width: 130,
                height: 130,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: kRed,
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x88E74C3C),
                      blurRadius: 32,
                      spreadRadius: 8,
                    ),
                  ],
                ),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.sos_rounded,
                        size: 44, color: Colors.white),
                    SizedBox(height: 4),
                    Text(
                      'ACTIVE',
                      style: TextStyle(
                        fontFamily: 'Outfit',
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        color: Colors.white,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildCancelWindow() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          Text(
            'SOS will escalate in $_cancelCountdown seconds',
            style: const TextStyle(
              fontFamily: 'Outfit',
              fontWeight: FontWeight.w700,
              fontSize: 15,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Hoppo admin has been notified. Cancel if this was accidental.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Outfit',
              fontSize: 12,
              color: Colors.white.withOpacity(0.6),
            ),
          ),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: _cancelCountdown / 10,
            backgroundColor: Colors.white12,
            valueColor: const AlwaysStoppedAnimation<Color>(kRed),
            borderRadius: BorderRadius.circular(8),
            minHeight: 5,
          ),
        ],
      ),
    );
  }

  Widget _buildEscalationStatus() {
    final current = _escalationStep > 0 && _escalationStep <= _steps.length
        ? _steps[_escalationStep - 1]
        : null;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kRed.withOpacity(0.2),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kRed.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded,
              color: Colors.white, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              current != null
                  ? 'Contacting: ${current.label}'
                  : 'All contacts alerted',
              style: const TextStyle(
                fontFamily: 'Outfit',
                fontWeight: FontWeight.w700,
                fontSize: 14,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEscalationList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'ESCALATION CHAIN',
          style: TextStyle(
            fontFamily: 'Outfit',
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: Colors.white.withOpacity(0.5),
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 12),
        ..._steps.asMap().entries.map((e) =>
            _buildActiveChainRow(e.key, e.value)),
      ],
    );
  }

  Widget _buildActiveChainRow(int index, _EscalationStep step) {
    final stepNum = index + 1;
    final isCompleted = _escalationStep > stepNum;
    final isCurrent = _cancelCountdown <= 0 && _escalationStep == stepNum;
    final isPending = _escalationStep < stepNum;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isCurrent
              ? kRed.withOpacity(0.25)
              : isCompleted
                  ? Colors.white.withOpacity(0.05)
                  : Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isCurrent
                ? kRed.withOpacity(0.6)
                : isCompleted
                    ? Colors.white.withOpacity(0.1)
                    : Colors.white.withOpacity(0.06),
            width: isCurrent ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: isCompleted
                    ? kGreen.withOpacity(0.2)
                    : isCurrent
                        ? kRed.withOpacity(0.3)
                        : Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: isCompleted
                    ? const Icon(Icons.check_rounded,
                        color: kGreen, size: 18)
                    : isCurrent
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: kRed,
                            ),
                          )
                        : Text(
                            '$stepNum',
                            style: TextStyle(
                              fontFamily: 'Outfit',
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                              color: Colors.white
                                  .withOpacity(isPending ? 0.3 : 0.8),
                            ),
                          ),
              ),
            ),
            const SizedBox(width: 14),
            Icon(
              step.icon,
              size: 20,
              color: isCompleted
                  ? kGreen
                  : isCurrent
                      ? Colors.white
                      : Colors.white.withOpacity(0.3),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    step.label,
                    style: TextStyle(
                      fontFamily: 'Outfit',
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      color: isCompleted
                          ? kGreen
                          : isCurrent
                              ? Colors.white
                              : Colors.white.withOpacity(0.3),
                    ),
                  ),
                  Text(
                    step.sublabel,
                    style: TextStyle(
                      fontFamily: 'Outfit',
                      fontSize: 11,
                      color: Colors.white.withOpacity(
                          isCompleted || isCurrent ? 0.6 : 0.2),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Headers ─────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return Container(
      color: kSurface,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: kRedLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.sos_rounded, color: kRed, size: 20),
          ),
          const SizedBox(width: 12),
          const Text(
            'Emergency SOS',
            style: TextStyle(
              fontFamily: 'Outfit',
              fontWeight: FontWeight.w700,
              fontSize: 17,
              color: kTextDark,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveHeader() {
    return Container(
      color: Colors.white.withOpacity(0.05),
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: kRed.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child:
                const Icon(Icons.sos_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          const Text(
            'SOS Active',
            style: TextStyle(
              fontFamily: 'Outfit',
              fontWeight: FontWeight.w700,
              fontSize: 17,
              color: Colors.white,
            ),
          ),
          const Spacer(),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: kRed.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kRed.withOpacity(0.4)),
            ),
            child: const Text(
              '● LIVE',
              style: TextStyle(
                fontFamily: 'Outfit',
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Data class ─────────────────────────────────────────────────────────

class _EscalationStep {
  final IconData icon;
  final String label;
  final String sublabel;
  final Color color;
  const _EscalationStep({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.color,
  });
}