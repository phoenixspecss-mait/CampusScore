import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hoppo/providers/parent_provider.dart';
import 'package:hoppo/services/models/child_model.dart';
import 'package:hoppo/widgets/hoppo_theme.dart';
import 'package:hoppo/services/services/child_service.dart';
import 'dart:math';

class ProfileView extends StatelessWidget {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ParentProvider>();
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      backgroundColor: kBackground,
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: kSurface,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded, color: kTextMid),
            onPressed: () => _confirmSignOut(context),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildParentCard(user),
          const SizedBox(height: 16),

          // Section Header with Add Child Action
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildSectionHeader('Children & Subscriptions'),
              TextButton.icon(
                onPressed: () => _showAddChildSheet(context),
                icon: const Icon(
                  Icons.add_circle_outline_rounded,
                  size: 16,
                  color: kHoppoOrange,
                ),
                label: const Text(
                  'Add Child',
                  style: TextStyle(
                    fontFamily: 'Outfit',
                    color: kHoppoOrange,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          if (provider.children.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: kSurface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE8E8E8)),
              ),
              child: const Text(
                'No children added yet. Tap "Add Child" to setup safe corridors tracking.',
                style: TextStyle(
                  fontFamily: 'Outfit',
                  color: kTextMid,
                  fontSize: 13,
                ),
                textAlign: TextAlign.center,
              ),
            )
          else
            ...provider.children
                .map((child) => _buildChildCard(context, child as ChildModel))
                .toList(),

          const SizedBox(height: 16),
          _buildSectionHeader('Safety Settings'),
          const SizedBox(height: 8),
          _buildSafetySettings(context, provider),
          const SizedBox(height: 16),
          _buildSectionHeader('Subscription & Billing'),
          const SizedBox(height: 8),
          _buildBillingCard(context),
          const SizedBox(height: 16),
          _buildSectionHeader('Support'),
          const SizedBox(height: 8),
          _buildSupportSection(context),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildParentCard(User? user) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundImage: user?.photoURL != null
                ? NetworkImage(user!.photoURL!)
                : null,
            backgroundColor: kHoppoOrangeLight,
            child: user?.photoURL == null
                ? Text(
                    user?.displayName?.isNotEmpty == true
                        ? user!.displayName![0]
                        : 'P',
                    style: const TextStyle(
                      fontFamily: 'Outfit',
                      fontWeight: FontWeight.w700,
                      fontSize: 22,
                      color: kHoppoOrange,
                    ),
                  )
                : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user?.displayName ?? 'Parent',
                  style: const TextStyle(
                    fontFamily: 'Outfit',
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                    color: kTextDark,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  user?.email ?? '',
                  style: const TextStyle(
                    fontFamily: 'Outfit',
                    color: kTextMid,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.edit_rounded, color: kHoppoOrange, size: 20),
            onPressed: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildChildCard(BuildContext context, ChildModel child) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE8E8E8)),
      ),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        leading: CircleAvatar(
          radius: 20,
          backgroundColor: kHoppoOrangeLight,
          child: Text(
            child.name.isNotEmpty ? child.name[0] : '?',
            style: const TextStyle(
              fontFamily: 'Outfit',
              fontWeight: FontWeight.w700,
              color: kHoppoOrange,
            ),
          ),
        ),
        title: Text(
          child.name,
          style: const TextStyle(
            fontFamily: 'Outfit',
            fontWeight: FontWeight.w700,
            fontSize: 15,
            color: kTextDark,
          ),
        ),
        subtitle: Text(
          'Boarding PIN: ${child.boardingPin}',
          style: const TextStyle(
            fontFamily: 'Outfit',
            color: kTextMid,
            fontSize: 12,
          ),
        ),
        children: [
          const Divider(),
          const SizedBox(height: 8),
          _buildEmergencyContacts(context, child),
        ],
      ),
    );
  }

  Widget _buildEmergencyContacts(BuildContext context, ChildModel child) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'Emergency Contacts',
              style: TextStyle(
                fontFamily: 'Outfit',
                fontWeight: FontWeight.w700,
                fontSize: 13,
                color: kTextDark,
              ),
            ),
            const Spacer(),
            TextButton.icon(
              onPressed: () => _addContactDialog(context, child.childId),
              icon: const Icon(
                Icons.add_rounded,
                size: 16,
                color: kHoppoOrange,
              ),
              label: const Text(
                'Add',
                style: TextStyle(
                  fontFamily: 'Outfit',
                  color: kHoppoOrange,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        if (child.emergencyContacts.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'No emergency contacts added.',
              style: TextStyle(
                fontFamily: 'Outfit',
                color: kTextMid,
                fontSize: 13,
              ),
            ),
          )
        else
          ...child.emergencyContacts.map(
            (c) => ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(
                Icons.person_rounded,
                color: kHoppoOrange,
                size: 20,
              ),
              title: Text(
                c.name,
                style: const TextStyle(
                  fontFamily: 'Outfit',
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
              subtitle: Text(
                '${c.relation} · ${c.phone}',
                style: const TextStyle(
                  fontFamily: 'Outfit',
                  color: kTextMid,
                  fontSize: 12,
                ),
              ),
              trailing: IconButton(
                icon: const Icon(
                  Icons.delete_outline_rounded,
                  color: kRed,
                  size: 18,
                ),
                onPressed: () => _confirmDeleteContact(
                  context,
                  child.childId,
                  c.contactId,
                  c.name,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildSafetySettings(BuildContext context, ParentProvider provider) {
    final hasChild = provider.selectedChild != null;
    final childName = provider.selectedChild?.name ?? 'Child';

    return Container(
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE8E8E8)),
      ),
      child: Column(
        children: [
          _settingsTile(
            icon: Icons.speed_rounded,
            label: 'Speed Alert Threshold',
            value: hasChild ? 'Configure' : 'No Active Child',
            onTap: () {
              if (!hasChild) return;
              _showSpeedThresholdDialog(
                context,
                provider.selectedChild!.childId,
              );
            },
          ),
          const Divider(height: 1),
          _settingsTile(
            icon: Icons.alt_route_rounded,
            label: 'Route Deviation Alert',
            value: '150m corridor',
            onTap: () {},
          ),
          const Divider(height: 1),
          _settingsTile(
            icon: Icons.notifications_rounded,
            label: 'SOS Alert Contacts',
            value: 'Manage',
            onTap: () {},
          ),
          const Divider(height: 1),
          _settingsTile(
            icon: Icons.lock_rounded,
            label: 'Boarding PIN',
            value: hasChild ? 'Change' : 'No Active Child',
            onTap: () {
              if (!hasChild) return;
              _showChangePinDialog(context, provider.selectedChild!.childId);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBillingCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE8E8E8)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: kHoppoOrangeLight,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.subscriptions_rounded,
                  color: kHoppoOrange,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'School Cab Subscription',
                      style: TextStyle(
                        fontFamily: 'Outfit',
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: kTextDark,
                      ),
                    ),
                    Text(
                      'Active · Renews July 1',
                      style: TextStyle(
                        fontFamily: 'Outfit',
                        color: kGreen,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Text(
                '₹350/mo',
                style: TextStyle(
                  fontFamily: 'Outfit',
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  color: kTextDark,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: kHoppoOrange),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () {},
              child: const Text(
                'Manage Subscription',
                style: TextStyle(
                  fontFamily: 'Outfit',
                  color: kHoppoOrange,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSupportSection(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE8E8E8)),
      ),
      child: Column(
        children: [
          _settingsTile(
            icon: Icons.help_rounded,
            label: 'Help & FAQ',
            value: '',
            onTap: () {},
          ),
          const Divider(height: 1),
          _settingsTile(
            icon: Icons.privacy_tip_rounded,
            label: 'Privacy Policy',
            value: '',
            onTap: () {},
          ),
          const Divider(height: 1),
          _settingsTile(
            icon: Icons.star_rounded,
            label: 'Rate Hoppo',
            value: '',
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget _settingsTile({
    required IconData icon,
    required String label,
    required String value,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: kHoppoOrange, size: 20),
      title: Text(
        label,
        style: const TextStyle(
          fontFamily: 'Outfit',
          fontWeight: FontWeight.w500,
          fontSize: 14,
        ),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (value.isNotEmpty)
            Text(
              value,
              style: const TextStyle(
                fontFamily: 'Outfit',
                color: kTextMid,
                fontSize: 13,
              ),
            ),
          const SizedBox(width: 4),
          const Icon(Icons.chevron_right_rounded, color: kTextMid, size: 18),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontFamily: 'Outfit',
        fontWeight: FontWeight.w700,
        fontSize: 13,
        color: kTextMid,
        letterSpacing: 0.5,
      ),
    );
  }

  void _showAddChildSheet(BuildContext context) {
    final nameController = TextEditingController();
    final schoolController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Container(
          decoration: const BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Add Child Profile',
                style: TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: kTextDark,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Register your child to securely assign them to a safe subscription corridor.',
                style: TextStyle(
                  fontFamily: 'Outfit',
                  color: kTextMid,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 20),
              _inputField(
                nameController,
                'Child\'s Name',
                Icons.person_outline_rounded,
              ),
              const SizedBox(height: 12),
              _inputField(
                schoolController,
                'School Name or ID',
                Icons.school_outlined,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kHoppoOrange,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () async {
                    if (nameController.text.trim().isEmpty ||
                        schoolController.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Please fill in all details'),
                        ),
                      );
                      return;
                    }

                    final parentProvider = Provider.of<ParentProvider>(
                      context,
                      listen: false,
                    );

                    // Cleanly auto-generate a secure random 4-digit PIN for the security check-in architecture // Ensure you have this import at the very top of your file if not present
                    final randomPin = (1000 + Random().nextInt(9000))
                        .toString(); // Generates a number between 1000 and 9999

                    try {
                      // Satisfies all 3 required named parameters exactly as declared in ParentProvider
                      await parentProvider.addChild(
                        name: nameController.text.trim(),
                        schoolId: schoolController.text.trim(),
                        boardingPin: randomPin,
                      );
                      if (context.mounted) Navigator.pop(context);
                    } catch (e) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Error adding profile: $e')),
                        );
                      }
                    }
                  },
                  child: const Text(
                    'Confirm & Generate Security PIN',
                    style: TextStyle(
                      fontFamily: 'Outfit',
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSpeedThresholdDialog(BuildContext context, String childId) {
    final speedCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Speed Threshold',
          style: TextStyle(fontFamily: 'Outfit', fontWeight: FontWeight.w700),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Set accelerometer warning metric limit in km/h for alerts.',
              style: TextStyle(fontFamily: 'Outfit', fontSize: 13),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: speedCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'e.g. 40',
                suffixText: 'km/h',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kHoppoOrange),
            onPressed: () async {
              final val = int.tryParse(speedCtrl.text.trim());
              if (val != null) {
                await ChildService().updateSpeedThreshold(childId, val);
                if (context.mounted) Navigator.pop(context);
              }
            },
            child: const Text('Update', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showChangePinDialog(BuildContext context, String childId) {
    final pinCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Change Boarding PIN',
          style: TextStyle(fontFamily: 'Outfit', fontWeight: FontWeight.w700),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Enter a new 4-digit verification code required for driver check-in.',
              style: TextStyle(fontFamily: 'Outfit', fontSize: 13),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: pinCtrl,
              keyboardType: TextInputType.number,
              maxLength: 4,
              decoration: InputDecoration(
                hintText: '4-Digit PIN',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kHoppoOrange),
            onPressed: () async {
              if (pinCtrl.text.trim().length == 4) {
                await ChildService().updateBoardingPin(
                  childId,
                  pinCtrl.text.trim(),
                );
                if (context.mounted) Navigator.pop(context);
              }
            },
            child: const Text('Save', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _addContactDialog(BuildContext context, String childId) {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final relationCtrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetCtx) => Padding(
        padding: EdgeInsets.only(
          left: 24,
          right: 24,
          top: 24,
          bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Add Emergency Contact',
              style: TextStyle(
                fontFamily: 'Outfit',
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 20),
            _inputField(nameCtrl, 'Full Name', Icons.person_rounded),
            const SizedBox(height: 12),
            _inputField(
              phoneCtrl,
              'Phone Number',
              Icons.phone_rounded,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 12),
            _inputField(
              relationCtrl,
              'Relation (e.g. Mother)',
              Icons.family_restroom_rounded,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kHoppoOrange,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () async {
                  if (nameCtrl.text.trim().isEmpty ||
                      phoneCtrl.text.trim().isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Name and phone are required.',
                          style: TextStyle(fontFamily: 'Outfit'),
                        ),
                        backgroundColor: kRed,
                      ),
                    );
                    return;
                  }
                  await ChildService().addEmergencyContact(
                    childId,
                    nameCtrl.text.trim(),
                    phoneCtrl.text.trim(),
                    relationCtrl.text.trim(),
                  );
                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text(
                  'Save Contact',
                  style: TextStyle(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDeleteContact(
    BuildContext context,
    String childId,
    String contactId,
    String name,
  ) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Remove Contact?',
          style: TextStyle(fontFamily: 'Outfit', fontWeight: FontWeight.w700),
        ),
        content: Text(
          'Remove $name from emergency contacts?',
          style: const TextStyle(fontFamily: 'Outfit'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: kTextMid)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kRed),
            onPressed: () async {
              Navigator.pop(context);
              await ChildService().removeEmergencyContact(childId, contactId);
            },
            child: const Text(
              'Remove',
              style: TextStyle(color: Colors.white, fontFamily: 'Outfit'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _inputField(
    TextEditingController ctrl,
    String hint,
    IconData icon, {
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: ctrl,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(
          fontFamily: 'Outfit',
          color: kTextMid,
          fontSize: 14,
        ),
        prefixIcon: Icon(icon, color: kHoppoOrange, size: 20),
        filled: true,
        fillColor: kBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE0E0E0)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE0E0E0)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: kHoppoOrange),
        ),
      ),
    );
  }

  void _confirmSignOut(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Sign Out?',
          style: TextStyle(fontFamily: 'Outfit', fontWeight: FontWeight.w700),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: kTextMid)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kHoppoOrange),
            onPressed: () {
              FirebaseAuth.instance.signOut();
              Navigator.pop(context);
            },
            child: const Text(
              'Sign Out',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Outfit',
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
