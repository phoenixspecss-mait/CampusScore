import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:hoppo/providers/driver_provider.dart';
import 'package:hoppo/widgets/hoppo_theme.dart';
import 'driver_route_view.dart';
import 'package:hoppo/views/driver_sos_view.dart';
class DriverShell extends StatefulWidget {
  const DriverShell({super.key});

  @override
  State<DriverShell> createState() => _DriverShellState();
}

class _DriverShellState extends State<DriverShell> {
  int _idx = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DriverProvider>().init();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DriverProvider>();

    final pages = [
      const DriverRouteView(),
      const DriverSosView(),
    ];

    return Scaffold(
      body: pages[_idx],
      bottomNavigationBar: 
      Container(
        decoration: const BoxDecoration(
          color: kSurface,
          boxShadow: [
            BoxShadow(
                color: Color(0x10000000),
                blurRadius: 12,
                offset: Offset(0, -2)),
          ],
        ),
        child: SafeArea(
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: _modeToggle(provider),
                ),
                const SizedBox(width: 8),
                _navBtn(0, Icons.route_rounded, Icons.route_outlined,
                    'Route'),
                _navBtn(1, Icons.emergency_rounded,
                    Icons.emergency_outlined, 'SOS'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _modeToggle(DriverProvider provider) {
    return Container(
      height: 44,
      decoration: BoxDecoration(
        color: const Color(0xFFF0F0F0),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          _modeBtn('school', 'School', Icons.school_rounded, provider),
          _modeBtn(
              'employee', 'Employee', Icons.work_rounded, provider),
        ],
      ),
    );
  }

  Widget _modeBtn(String mode, String label, IconData icon,
      DriverProvider provider) {
    final active = provider.mode == mode;
    return Expanded(
      child: GestureDetector(
        onTap: () => provider.switchMode(mode),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: active ? kHoppoOrange : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  size: 14,
                  color: active ? Colors.white : kTextMid),
              const SizedBox(width: 4),
              Text(label,
                  style: TextStyle(
                      fontFamily: 'Outfit',
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: active ? Colors.white : kTextMid)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navBtn(
      int index, IconData active, IconData inactive, String label) {
    final sel = _idx == index;
    return GestureDetector(
      onTap: () => setState(() => _idx = index),
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: sel ? kHoppoOrangeLight : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(sel ? active : inactive,
                color: sel ? kHoppoOrange : kTextMid, size: 22),
            const SizedBox(height: 2),
            Text(label,
                style: TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 11,
                    fontWeight:
                        sel ? FontWeight.w700 : FontWeight.w400,
                    color: sel ? kHoppoOrange : kTextMid)),
          ],
        ),
      ),
    );
  }
}