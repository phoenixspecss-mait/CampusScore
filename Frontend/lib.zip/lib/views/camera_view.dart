import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hoppo/providers/parent_provider.dart';
import 'package:hoppo/widgets/hoppo_theme.dart';
import 'package:hoppo/widgets/shared_widgets.dart';

class CameraView extends StatelessWidget {
  const CameraView({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ParentProvider>();
    final cab = provider.activeCab;
    final ride = provider.activeRide;

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: ride == null || cab == null
            ? _buildNoFeedState()
            : _buildFeedState(context, provider, cab),
      ),
    );
  }

  Widget _buildNoFeedState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.white10,
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Icon(Icons.videocam_off_rounded, size: 40, color: Colors.white54),
          ),
          const SizedBox(height: 20),
          const Text('No Active Ride',
              style: TextStyle(
                  fontFamily: 'Outfit', color: Colors.white, fontWeight: FontWeight.w700, fontSize: 18)),
          const SizedBox(height: 8),
          const Text(
            'Live cabin feed will appear here\nduring an active ride.',
            textAlign: TextAlign.center,
            style: TextStyle(fontFamily: 'Outfit', color: Colors.white38, fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildFeedState(BuildContext context, ParentProvider provider, cab) {
    return Column(
      children: [
        _buildTopBar(context, provider),
        Expanded(child: _buildVideoFeed(cab)),
        _buildControls(context, provider),
      ],
    );
  }

  Widget _buildTopBar(BuildContext context, ParentProvider provider) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          const HoppoLogo(size: 32),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(provider.selectedChild?.name ?? 'Cabin Feed',
                  style: const TextStyle(
                      fontFamily: 'Outfit', color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
              Row(
                children: [
                  Container(width: 6, height: 6,
                      decoration: const BoxDecoration(color: kGreen, shape: BoxShape.circle)),
                  const SizedBox(width: 4),
                  const Text('LIVE',
                      style: TextStyle(
                          fontFamily: 'Outfit', color: kGreen, fontSize: 11,
                          fontWeight: FontWeight.w600, letterSpacing: 1.2)),
                ],
              ),
            ],
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.fullscreen_rounded, color: Colors.white),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Fullscreen available after video integration.',
                      style: TextStyle(fontFamily: 'Outfit')),
                  backgroundColor: Colors.black87,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildVideoFeed(cab) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Stack(
        children: [
          const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.videocam_rounded, size: 48, color: Colors.white24),
                SizedBox(height: 12),
                Text('Connecting to cabin camera...',
                    style: TextStyle(fontFamily: 'Outfit', color: Colors.white38, fontSize: 13)),
              ],
            ),
          ),
          Positioned(
            top: 12, left: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)),
              child: const Text('CAM 1 · CABIN',
                  style: TextStyle(fontFamily: 'Outfit', color: Colors.white70, fontSize: 11)),
            ),
          ),
          Positioned(
            top: 12, right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: kRed.withOpacity(0.8), borderRadius: BorderRadius.circular(8)),
              child: const Text('REC',
                  style: TextStyle(fontFamily: 'Outfit', color: Colors.white, fontWeight: FontWeight.w700, fontSize: 11)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControls(BuildContext context, ParentProvider provider) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _controlButton(
                icon: provider.audioEnabled ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                label: provider.audioEnabled ? 'Audio On' : 'Audio Off',
                active: provider.audioEnabled,
                onTap: provider.toggleAudio,
              ),
              _talkbackButton(provider),
              _controlButton(
                icon: Icons.screenshot_rounded,
                label: 'Snapshot',
                active: false,
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Snapshot saved to audit pack.', style: TextStyle(fontFamily: 'Outfit')),
                    backgroundColor: kHoppoOrange,
                  ),
                ),
              ),
              _controlButton(
                icon: Icons.flag_rounded,
                label: 'Report',
                active: false,
                onTap: () => _showReportDialog(context, provider),
              ),
            ],
          ),
          const SizedBox(height: 24),
          if (provider.talkbackActive) _buildTalkbackBanner(),
        ],
      ),
    );
  }

  Widget _controlButton({required IconData icon, required String label, required bool active, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(color: active ? kHoppoOrange : Colors.white12, shape: BoxShape.circle),
            child: Icon(icon, color: active ? Colors.white : Colors.white70, size: 24),
          ),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontFamily: 'Outfit', color: Colors.white54, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _talkbackButton(ParentProvider provider) {
    return GestureDetector(
      onTapDown: (_) => provider.toggleTalkback(),
      onTapUp: (_) => provider.toggleTalkback(),
      child: Column(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
                color: provider.talkbackActive ? kGreen : Colors.white12, shape: BoxShape.circle),
            child: Icon(
              provider.talkbackActive ? Icons.mic_rounded : Icons.mic_none_rounded,
              color: provider.talkbackActive ? Colors.white : Colors.white70, size: 24,
            ),
          ),
          const SizedBox(height: 6),
          Text(provider.talkbackActive ? 'Release' : 'Hold Talk',
              style: const TextStyle(fontFamily: 'Outfit', color: Colors.white54, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildTalkbackBanner() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
      decoration: BoxDecoration(
        color: kGreen.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kGreen.withOpacity(0.4)),
      ),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.mic_rounded, color: kGreen, size: 16),
          SizedBox(width: 8),
          Text('Speaking to cabin... Driver can hear you.',
              style: TextStyle(fontFamily: 'Outfit', color: kGreen, fontWeight: FontWeight.w600, fontSize: 13)),
        ],
      ),
    );
  }

  void _showReportDialog(BuildContext context, ParentProvider provider) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E1E),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Report an Issue',
                style: TextStyle(fontFamily: 'Outfit', color: Colors.white, fontWeight: FontWeight.w700, fontSize: 18)),
            const SizedBox(height: 16),
            ...['Driver behaviour', 'Route deviation', 'Camera not working', 'Child not boarded', 'Other']
                .map((issue) => ListTile(
                      title: Text(issue, style: const TextStyle(fontFamily: 'Outfit', color: Colors.white70)),
                      leading: const Icon(Icons.flag_rounded, color: kHoppoOrange),
                      onTap: () {
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Reported: $issue', style: const TextStyle(fontFamily: 'Outfit')), backgroundColor: kRed),
                        );
                      },
                    ))
                .toList(),
          ],
        ),
      ),
    );
  }
}