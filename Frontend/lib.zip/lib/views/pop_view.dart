import 'package:flutter/material.dart';
import 'package:hoppo/services/auth/auth_service.dart';
import 'package:hoppo/services/db/database_provider.dart';
import 'package:provider/provider.dart';

class PopView extends StatefulWidget {
  const PopView({super.key});

  @override
  State<PopView> createState() => _PopViewState();
}

class _PopViewState extends State<PopView> {
  String? _loadingChoice;

  Future<void> _handleSelection(BuildContext context, String role) async {
    final uid = AuthService.firebase().currentUser?.uid ?? '';
    if (uid.isEmpty) return;

    setState(() => _loadingChoice = role);

    try {
      await Provider.of<DatabaseProvider>(context, listen: false)
          .completeForm(uid, role);

      if (mounted) {
        setState(() => _loadingChoice = null);
        // Pop the dialog — main.dart RoleRouter will rebuild and route correctly
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loadingChoice = null);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving choice: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 24.0),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 340),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.black, width: 3.5),
          borderRadius: BorderRadius.circular(24),
          boxShadow: const [
            BoxShadow(offset: Offset(0, 8), blurRadius: 0, color: Colors.black),
          ],
        ),
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Who are you?',
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  letterSpacing: 0.5),
            ),
            const SizedBox(height: 6),
            Text(
              'Select your role to set up your profile',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade600),
            ),
            const SizedBox(height: 24),
            _buildCard(context, 'parent', 'Parent', 'Track my child\'s school cab',
                Icons.family_restroom_rounded,
                const Color(0xFFC25A3A), const Color(0xFFFDF0EB)),
            const SizedBox(height: 12),
            _buildCard(context, 'driver', 'Driver', 'I operate a hoppo cab',
                Icons.drive_eta_rounded,
                const Color(0xFF2563EB), const Color(0xFFEFF6FF)),
            const SizedBox(height: 12),
            _buildCard(context, 'school', 'School Admin',
                'Manage transport for my school',
                Icons.school_rounded,
                const Color(0xFF16A34A), const Color(0xFFF0FDF4)),
            const SizedBox(height: 12),
            _buildCard(context, 'business', 'Business / HR',
                'Set up employee commute shuttles',
                Icons.business_center_rounded,
                const Color(0xFF7C3AED), const Color(0xFFF5F3FF)),
            const SizedBox(height: 12),
            _buildCard(context, 'rider', 'Adult Rider', 'Hop-In on a nearby cab',
                Icons.directions_walk_rounded,
                const Color(0xFFD97706), const Color(0xFFFFFBEB)),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(
    BuildContext context,
    String role,
    String label,
    String subLabel,
    IconData icon,
    Color iconColor,
    Color iconBg,
  ) {
    final isLoading = _loadingChoice == role;
    final isAnyLoading = _loadingChoice != null;

    return InkWell(
      onTap: isAnyLoading ? null : () => _handleSelection(context, role),
      borderRadius: BorderRadius.circular(16),
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 200),
        opacity: isAnyLoading && !isLoading ? 0.4 : 1.0,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12.0),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.black, width: 2.5),
            borderRadius: BorderRadius.circular(16),
            boxShadow: const [
              BoxShadow(offset: Offset(0, 4), blurRadius: 0, color: Colors.black),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: iconBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.black, width: 1.5),
                ),
                child: Center(child: Icon(icon, color: iconColor, size: 26)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black)),
                    const SizedBox(height: 2),
                    Text(subLabel,
                        style: TextStyle(
                            fontSize: 11,
                            color: Colors.grey.shade600,
                            fontWeight: FontWeight.w500)),
                  ],
                ),
              ),
              isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.5, color: Colors.black),
                    )
                  : const Icon(Icons.chevron_right, color: Colors.black, size: 24),
            ],
          ),
        ),
      ),
    );
  }
}