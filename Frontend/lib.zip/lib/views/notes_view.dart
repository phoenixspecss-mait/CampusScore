import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hoppo/providers/parent_provider.dart';
import 'package:hoppo/widgets/hoppo_theme.dart';
import 'package:hoppo/widgets/shared_widgets.dart';

class NotesView extends StatefulWidget {
  const NotesView({super.key});

  @override
  State<NotesView> createState() => _NotesViewState();
}

class _NotesViewState extends State<NotesView> {
  // 1. TODO: Declare your GoogleMapController variable right here!

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ParentProvider>();

    return Scaffold(
      backgroundColor: kBackground,
      body: SafeArea(
        child: provider.loading
            ? const Center(child: CircularProgressIndicator(color: kHoppoOrange))
            : Column(
                children: [
                  _buildHeader(provider),
                  if (provider.children.length > 1) _buildChildSelector(provider),
                  Expanded(child: _buildTrackingWorkspace(provider)),
                ],
              ),
      ),
    );
  }

  Widget _buildHeader(ParentProvider provider) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          const HoppoLogo(size: 36),
          const SizedBox(width: 10),
          const Text(
            'Hoppo',
            style: TextStyle(
              fontFamily: 'Outfit',
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: kHoppoOrange,
            ),
          ),
          const Spacer(),
          SOSButton(
            onPressed: () => _confirmSOS(context, provider),
          ),
        ],
      ),
    );
  }

  Widget _buildChildSelector(ParentProvider provider) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: provider.children.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final child = provider.children[i];
          return ChildSelectorChip(
            name: child.name,
            selected: provider.selectedChild?.childId == child.childId,
            onTap: () => provider.selectChild(child),
          );
        },
      ),
    );
  }

  Widget _buildTrackingWorkspace(ParentProvider provider) {
    final ride = provider.activeRide;
    final cab = provider.activeCab;

    if (ride == null || cab == null) {
      return _buildNoRideState(provider);
    }

    // 2. TODO: You are in complete control here. 
    // Build your layout container, set up the GoogleMap widget, 
    // code the custom orange marker, and handle the camera tracking logic!
    return Column(
      children: [
        const Expanded(
          child: Center(
            child: Text(
              'Map implementation placeholder.\nWrite your GoogleMap widget here!',
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: 'Outfit', color: kTextMid),
            ),
          ),
        ),
        _buildStatusCard(provider, ride, cab),
      ],
    );
  }

  Widget _buildStatusCard(ParentProvider provider, dynamic ride, dynamic cab) {
    final child = provider.selectedChild;
    final eta = ride.eta;
    final etaStr = eta != null
        ? '${eta.hour.toString().padLeft(2, '0')}:${eta.minute.toString().padLeft(2, '0')}'
        : '--:--';

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 22,
                backgroundColor: kHoppoOrangeLight,
                child: Text(
                  child?.name.isNotEmpty == true ? child!.name[0] : '?',
                  style: const TextStyle(
                    fontFamily: 'Outfit',
                    fontWeight: FontWeight.w700,
                    color: kHoppoOrange,
                    fontSize: 18,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    child?.name ?? 'Unknown',
                    style: const TextStyle(
                      fontFamily: 'Outfit',
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: kTextDark,
                    ),
                  ),
                  const SizedBox(height: 2),
                  StatusPill(
                    label: ride.boarded ? '● In Cab' : '◌ Awaiting Boarding',
                    color: ride.boarded ? kGreen : kAmber,
                    bgColor: ride.boarded ? kGreenLight : kAmberLight,
                  ),
                ],
              ),
              const Spacer(),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('ETA',
                      style: TextStyle(fontFamily: 'Outfit', color: kTextMid, fontSize: 12)),
                  Text(
                    etaStr,
                    style: const TextStyle(
                      fontFamily: 'Outfit',
                      fontWeight: FontWeight.w800,
                      fontSize: 22,
                      color: kTextDark,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _infoChip(Icons.speed_rounded, '${cab.speed.toStringAsFixed(0)} km/h',
                  cab.speed > 40 ? kRed : kTextMid),
              const SizedBox(width: 12),
              if (cab.routeDeviation)
                _infoChip(Icons.alt_route_rounded, 'Route Deviation', kRed)
              else
                _infoChip(Icons.route_rounded, 'On Route', kGreen),
              const SizedBox(width: 12),
              _infoChip(Icons.shield_rounded, '12 Active', kHoppoOrange),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoChip(IconData icon, String label, Color color) {
    return Row(
      children: [
        Icon(icon, size: 14, color: color),
        const SizedBox(width: 4),
        Text(label,
            style: TextStyle(
                fontFamily: 'Outfit',
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: color)),
      ],
    );
  }

  Widget _buildNoRideState(ParentProvider provider) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: kHoppoOrangeLight,
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Icon(Icons.directions_car_rounded, size: 40, color: kHoppoOrange),
          ),
          const SizedBox(height: 20),
          Text(
            provider.selectedChild != null
                ? 'No active ride for ${provider.selectedChild!.name}'
                : 'No children linked yet',
            style: const TextStyle(
                fontFamily: 'Outfit', fontWeight: FontWeight.w600, fontSize: 16, color: kTextDark),
          ),
          const SizedBox(height: 8),
          const Text(
            'Live tracking will appear here during an active ride.',
            style: TextStyle(fontFamily: 'Outfit', color: kTextMid, fontSize: 13),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  void _confirmSOS(BuildContext context, ParentProvider provider) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Trigger SOS?',
            style: TextStyle(fontFamily: 'Outfit', fontWeight: FontWeight.w700)),
        content: const Text(
          'This will immediately alert the driver, school admin, and emergency contacts.',
          style: TextStyle(fontFamily: 'Outfit'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: kTextMid)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kRed),
            onPressed: () {
              Navigator.pop(context);
              provider.triggerSOS();
            },
            child: const Text('Yes, Trigger SOS',
                style: TextStyle(color: Colors.white, fontFamily: 'Outfit')),
          ),
        ],
      ),
    );
  }
}