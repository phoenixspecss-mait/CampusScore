import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:hoppo/providers/driver_provider.dart';
import 'package:hoppo/widgets/hoppo_theme.dart';
import 'package:hoppo/widgets/shared_widgets.dart';

class DriverRouteView extends StatelessWidget {
  const DriverRouteView({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DriverProvider>();

    return Scaffold(
      backgroundColor: kBackground,
      body: SafeArea(
        child: provider.loading
            ? const Center(
                child: CircularProgressIndicator(color: kHoppoOrange))
            : Column(
                children: [
                  _buildHeader(provider),
                  Expanded(
                    child: provider.activeRides.isEmpty
                        ? _buildNoRides()
                        : _buildRideList(context, provider),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildHeader(DriverProvider provider) {
    return Container(
      color: kSurface,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      child: Row(
        children: [
          const HoppoLogo(size: 34),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Driver Dashboard',
                  style: TextStyle(
                      fontFamily: 'Outfit',
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: kTextDark)),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: provider.mode == 'school'
                      ? kGreenLight
                      : const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  provider.mode == 'school'
                      ? '● School Mode'
                      : '● Employee Mode',
                  style: TextStyle(
                      fontFamily: 'Outfit',
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: provider.mode == 'school'
                          ? kGreen
                          : const Color(0xFF2563EB)),
                ),
              ),
            ],
          ),
          const Spacer(),
          Text('${provider.activeRides.length} stops',
              style: const TextStyle(
                  fontFamily: 'Outfit',
                  color: kTextMid,
                  fontWeight: FontWeight.w600,
                  fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildRideList(BuildContext context, DriverProvider provider) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: provider.activeRides.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, i) =>
          _buildRideCard(context, provider.activeRides[i], provider),
    );
  }

  Widget _buildRideCard(BuildContext context, Map<String, dynamic> ride,
      DriverProvider provider) {
    final boarded = ride['boarded'] == true;
    final deboarded = ride['deboarded'] == true;
    final rideId = ride['rideId'] as String;
    final childId = ride['childId'] as String? ?? '';
    final parentUid = ride['parentUid'] as String? ?? '';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: deboarded
              ? kGreen
              : boarded
                  ? kHoppoOrange
                  : const Color(0xFFE8E8E8),
          width: deboarded || boarded ? 1.5 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: kHoppoOrangeLight,
                child: Text(
                  childId.isNotEmpty ? childId[0].toUpperCase() : '?',
                  style: const TextStyle(
                      fontFamily: 'Outfit',
                      fontWeight: FontWeight.w700,
                      color: kHoppoOrange),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Child ID: $childId',
                        style: const TextStyle(
                            fontFamily: 'Outfit',
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                            color: kTextDark)),
                    const SizedBox(height: 2),
                    StatusPill(
                      label: deboarded
                          ? '✓ Arrived'
                          : boarded
                              ? '● In Cab'
                              : '◌ Not Boarded',
                      color: deboarded
                          ? kGreen
                          : boarded
                              ? kHoppoOrange
                              : kAmber,
                      bgColor: deboarded
                          ? kGreenLight
                          : boarded
                              ? kHoppoOrangeLight
                              : kAmberLight,
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (!deboarded) ...[
            const SizedBox(height: 14),
            Row(
              children: [
                if (!boarded)
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kHoppoOrange,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        padding:
                            const EdgeInsets.symmetric(vertical: 10),
                      ),
                      icon: const Icon(Icons.pin_rounded,
                          color: Colors.white, size: 16),
                      label: const Text('Verify PIN',
                          style: TextStyle(
                              fontFamily: 'Outfit',
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 13)),
                      onPressed: () => _verifyPinDialog(
                          context, provider, rideId, parentUid, childId),
                    ),
                  ),
                if (boarded) ...[
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kGreen,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        padding:
                            const EdgeInsets.symmetric(vertical: 10),
                      ),
                      icon: const Icon(Icons.flag_rounded,
                          color: Colors.white, size: 16),
                      label: const Text('Mark Arrived',
                          style: TextStyle(
                              fontFamily: 'Outfit',
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 13)),
                      onPressed: () => _confirmArrived(context, provider,
                          rideId, parentUid, childId),
                    ),
                  ),
                  const SizedBox(width: 10),
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: kAmber),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                    icon: const Icon(Icons.alt_route_rounded,
                        color: kAmber, size: 16),
                    label: const Text('Detour',
                        style: TextStyle(
                            fontFamily: 'Outfit',
                            color: kAmber,
                            fontWeight: FontWeight.w600,
                            fontSize: 13)),
                    onPressed: () => _confirmDetour(context, provider,
                        rideId, parentUid, childId),
                  ),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildNoRides() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
                color: kHoppoOrangeLight,
                borderRadius: BorderRadius.circular(20)),
            child: const Icon(Icons.route_rounded,
                size: 36, color: kHoppoOrange),
          ),
          const SizedBox(height: 16),
          const Text('No active rides',
              style: TextStyle(
                  fontFamily: 'Outfit',
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                  color: kTextDark)),
          const SizedBox(height: 6),
          const Text('Your assigned rides will appear here.',
              style: TextStyle(
                  fontFamily: 'Outfit', color: kTextMid, fontSize: 13)),
        ],
      ),
    );
  }

  void _verifyPinDialog(BuildContext context, DriverProvider provider,
      String rideId, String parentUid, String childId) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          left: 24,
          right: 24,
          top: 24,
          bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock_rounded, size: 36, color: kHoppoOrange),
            const SizedBox(height: 12),
            const Text('Enter Child\'s Boarding PIN',
                style: TextStyle(
                    fontFamily: 'Outfit',
                    fontWeight: FontWeight.w700,
                    fontSize: 18)),
            const SizedBox(height: 6),
            const Text('Ask the child for their 4-digit PIN.',
                style: TextStyle(
                    fontFamily: 'Outfit',
                    color: kTextMid,
                    fontSize: 13)),
            const SizedBox(height: 20),
            TextField(
              controller: ctrl,
              keyboardType: TextInputType.number,
              obscureText: true,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(4),
              ],
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 16),
              decoration: InputDecoration(
                hintText: '••••',
                hintStyle: const TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 32,
                    color: kTextMid,
                    letterSpacing: 16),
                filled: true,
                fillColor: kBackground,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: Color(0xFFE0E0E0)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(
                      color: kHoppoOrange, width: 1.5),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: Color(0xFFE0E0E0)),
                ),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kHoppoOrange,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () async {
                  if (ctrl.text.length != 4) return;
                  await provider.verifyPin(rideId, parentUid, childId);
                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Child boarded successfully.',
                            style: TextStyle(fontFamily: 'Outfit')),
                        backgroundColor: kGreen,
                      ),
                    );
                  }
                },
                child: const Text('Confirm Boarding',
                    style: TextStyle(
                        fontFamily: 'Outfit',
                        color: Colors.white,
                        fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmArrived(BuildContext context, DriverProvider provider,
      String rideId, String parentUid, String childId) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
        title: const Text('Mark as Arrived?',
            style: TextStyle(
                fontFamily: 'Outfit', fontWeight: FontWeight.w700)),
        content: const Text(
          'This will notify the parent that their child has arrived safely.',
          style: TextStyle(fontFamily: 'Outfit'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel',
                style: TextStyle(color: kTextMid)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kGreen),
            onPressed: () async {
              Navigator.pop(context);
              await provider.markArrived(rideId, parentUid, childId);
            },
            child: const Text('Confirm',
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Outfit')),
          ),
        ],
      ),
    );
  }

  void _confirmDetour(BuildContext context, DriverProvider provider,
      String rideId, String parentUid, String childId) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
        title: const Text('Report Detour?',
            style: TextStyle(
                fontFamily: 'Outfit', fontWeight: FontWeight.w700)),
        content: const Text(
          'This will alert the parent and school admin of a route deviation.',
          style: TextStyle(fontFamily: 'Outfit'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel',
                style: TextStyle(color: kTextMid)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kAmber),
            onPressed: () async {
              Navigator.pop(context);
              await provider.reportDetour(rideId, parentUid, childId);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Detour reported. Parents notified.',
                        style: TextStyle(fontFamily: 'Outfit')),
                    backgroundColor: kAmber,
                  ),
                );
              }
            },
            child: const Text('Report Detour',
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Outfit')),
          ),
        ],
      ),
    );
  }
}