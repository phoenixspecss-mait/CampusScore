import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hoppo/providers/parent_provider.dart';
import 'package:hoppo/views/camera_view.dart';
import 'package:hoppo/views/alert_view.dart';
import 'package:hoppo/views/notes_view.dart';
import 'package:hoppo/views/profile_view.dart';
import 'package:hoppo/widgets/hoppo_theme.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int curridx = 0;

  // FIX: use correct class names — ParentNotesView, ParentCameraView
  final List<Widget> _screens = const [
    NotesView(),
    CameraView(),
    AlertView(),
    ProfileView(),
  ];

  @override
  void initState() {
    super.initState();
    // FIX: call init() on ParentProvider so Firebase streams start
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ParentProvider>().init();
    });
  }

  @override
  Widget build(BuildContext context) {
    final unread = context.watch<ParentProvider>().unreadCount;

    return Scaffold(
      body: _screens[curridx],
      bottomNavigationBar: NavigationBar(
        backgroundColor: kSurface,
        onDestinationSelected: (int idx) {
          setState(() => curridx = idx);
        },
        // FIX: indicator color → Hoppo orange
        indicatorColor: kHoppoOrangeLight,
        selectedIndex: curridx,
        destinations: <Widget>[
          // FIX: correct icons per brand spec
          const NavigationDestination(
            icon: Icon(Icons.shield_rounded),
            label: 'Home',
          ),
          const NavigationDestination(
            icon: Icon(Icons.videocam_rounded),
            label: 'Camera',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: unread > 0,
              label: Text('$unread'),
              child: const Icon(Icons.notifications_rounded),
            ),
            label: 'Alerts',
          ),
          const NavigationDestination(
            icon: Icon(Icons.manage_accounts_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}