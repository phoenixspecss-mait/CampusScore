import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/parent_provider.dart';
import '../services/models/alert_model.dart';
import '../../widgets/hoppo_theme.dart';

class AlertView extends StatefulWidget {
  const AlertView({super.key});

  @override
  State<AlertView> createState() => _AlertViewState();
}

class _AlertViewState extends State<AlertView>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ParentProvider>();

    return Scaffold(
      backgroundColor: kBackground,
      appBar: AppBar(
        backgroundColor: kSurface,
        title: Row(
          children: [
            const Text('Alerts'),
            if (provider.unreadCount > 0) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: kRed,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${provider.unreadCount} new',
                  style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'Outfit',
                      fontSize: 11,
                      fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ],
        ),
        actions: [
          if (provider.unreadCount > 0)
            TextButton(
              onPressed: provider.markAllRead,
              child: const Text('Mark all read',
                  style: TextStyle(
                      fontFamily: 'Outfit',
                      color: kHoppoOrange,
                      fontWeight: FontWeight.w600)),
            ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: kHoppoOrange,
          labelColor: kHoppoOrange,
          unselectedLabelColor: kTextMid,
          labelStyle: const TextStyle(
              fontFamily: 'Outfit', fontWeight: FontWeight.w600, fontSize: 13),
          tabs: [
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.circle, size: 8, color: kRed),
                  const SizedBox(width: 6),
                  Text('Red (${provider.redAlerts.length})'),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.circle, size: 8, color: kAmber),
                  const SizedBox(width: 6),
                  Text('Amber (${provider.amberAlerts.length})'),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.circle, size: 8, color: kGreen),
                  const SizedBox(width: 6),
                  Text('Green (${provider.greenAlerts.length})'),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          if (provider.redAlertCount > 0) _buildRedBanner(provider),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildAlertList(provider.redAlerts, provider, AlertSeverity.red),
                _buildAlertList(provider.amberAlerts, provider, AlertSeverity.amber),
                _buildGreenSummary(provider.greenAlerts),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRedBanner(ParentProvider provider) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      color: kRed,
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: Colors.white, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '${provider.redAlertCount} critical alert${provider.redAlertCount > 1 ? 's' : ''} need your attention',
              style: const TextStyle(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                  fontSize: 13),
            ),
          ),
          TextButton(
            onPressed: () => _tabController.animateTo(0),
            child: const Text('View',
                style: TextStyle(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  Widget _buildAlertList(
      List<AlertModel> alerts, ParentProvider provider, AlertSeverity severity) {
    if (alerts.isEmpty) {
      return _buildEmptyState(severity);
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      itemCount: alerts.length,
      itemBuilder: (context, i) => _buildAlertTile(alerts[i], provider),
    );
  }

  Widget _buildAlertTile(AlertModel alert, ParentProvider provider) {
    final config = _severityConfig(alert.severity);
    final timeStr = DateFormat('hh:mm a').format(alert.timestamp);

    return GestureDetector(
      onTap: () {
        provider.markAlertRead(alert.alertId);
        if (alert.severity == AlertSeverity.red) {
          _showAlertDetail(alert, provider);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: alert.read ? kSurface : config['lightColor'],
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: alert.read ? const Color(0xFFE8E8E8) : config['color'],
            width: alert.read ? 1 : 1.5,
          ),
          boxShadow: [
            if (!alert.read)
              BoxShadow(
                color: (config['color'] as Color).withOpacity(0.15),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: config['lightColor'],
                  shape: BoxShape.circle,
                ),
                child: Icon(config['icon'], color: config['color'], size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      alert.message,
                      style: TextStyle(
                        fontFamily: 'Outfit',
                        fontWeight:
                            alert.read ? FontWeight.w500 : FontWeight.w700,
                        fontSize: 14,
                        color: kTextDark,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(timeStr,
                        style: const TextStyle(
                            fontFamily: 'Outfit',
                            color: kTextMid,
                            fontSize: 12)),
                  ],
                ),
              ),
              if (!alert.read)
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: config['color'],
                    shape: BoxShape.circle,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGreenSummary(List<AlertModel> alerts) {
    if (alerts.isEmpty) return _buildEmptyState(AlertSeverity.green);

    // Group by date for bundled silent summaries
    final grouped = <String, List<AlertModel>>{};
    for (final a in alerts) {
      final key = DateFormat('MMM d').format(a.timestamp);
      grouped.putIfAbsent(key, () => []).add(a);
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: grouped.entries.map((entry) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(entry.key,
                  style: const TextStyle(
                      fontFamily: 'Outfit',
                      fontWeight: FontWeight.w700,
                      color: kTextMid,
                      fontSize: 12)),
            ),
            Container(
              decoration: BoxDecoration(
                color: kGreenLight,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: kGreen.withOpacity(0.3)),
              ),
              child: Column(
                children: entry.value
                    .map((a) => ListTile(
                          dense: true,
                          leading: const Icon(Icons.check_circle_rounded,
                              color: kGreen, size: 18),
                          title: Text(a.message,
                              style: const TextStyle(
                                  fontFamily: 'Outfit',
                                  fontSize: 13,
                                  color: kTextDark)),
                          trailing: Text(
                              DateFormat('hh:mm a').format(a.timestamp),
                              style: const TextStyle(
                                  fontFamily: 'Outfit',
                                  fontSize: 11,
                                  color: kTextMid)),
                        ))
                    .toList(),
              ),
            ),
            const SizedBox(height: 8),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildEmptyState(AlertSeverity severity) {
    final config = _severityConfig(severity);
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(config['icon'], size: 48, color: config['color']),
          const SizedBox(height: 12),
          Text(
            'No ${severity.name} alerts',
            style: const TextStyle(
                fontFamily: 'Outfit',
                fontWeight: FontWeight.w600,
                fontSize: 16,
                color: kTextMid),
          ),
        ],
      ),
    );
  }

  void _showAlertDetail(AlertModel alert, ParentProvider provider) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: kRedLight,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_rounded, color: kRed),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(alert.message,
                        style: const TextStyle(
                            fontFamily: 'Outfit',
                            fontWeight: FontWeight.w700,
                            color: kRed)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text(
              DateFormat('EEEE, MMM d • hh:mm a').format(alert.timestamp),
              style: const TextStyle(
                  fontFamily: 'Outfit', color: kTextMid, fontSize: 13),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: kTextMid),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () {
                      provider.acknowledgeAlert(alert.alertId);
                      Navigator.pop(context);
                    },
                    child: const Text('Acknowledge',
                        style: TextStyle(fontFamily: 'Outfit', color: kTextDark)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kRed,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                      provider.triggerSOS();
                    },
                    child: const Text('Trigger SOS',
                        style: TextStyle(
                            fontFamily: 'Outfit',
                            color: Colors.white,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Map<String, dynamic> _severityConfig(AlertSeverity severity) {
    switch (severity) {
      case AlertSeverity.red:
        return {
          'color': kRed,
          'lightColor': kRedLight,
          'icon': Icons.warning_rounded,
        };
      case AlertSeverity.amber:
        return {
          'color': kAmber,
          'lightColor': kAmberLight,
          'icon': Icons.info_rounded,
        };
      case AlertSeverity.green:
        return {
          'color': kGreen,
          'lightColor': kGreenLight,
          'icon': Icons.check_circle_rounded,
        };
    }
  }
}