import 'package:flutter/material.dart';
import 'hoppo_theme.dart';

class HoppoLogo extends StatelessWidget {
  final double size;
  const HoppoLogo({super.key, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: _DiamondPainter(),
    );
  }
}

class _DiamondPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = kHoppoOrange;
    final rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Radius.circular(size.width * 0.22),
    );
    canvas.drawRRect(rrect, paint);

    final wp = Paint()..color = Colors.white;
    final path = Path();
    final cx = size.width / 2;
    final cy = size.height / 2;
    final hw = size.width * 0.32;
    final hh = size.height * 0.38;
    path.moveTo(cx, cy - hh);
    path.lineTo(cx + hw, cy);
    path.lineTo(cx, cy + hh);
    path.lineTo(cx - hw, cy);
    path.close();
    canvas.drawPath(path, wp);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ChildSelectorChip extends StatelessWidget {
  final String name;
  final bool selected;
  final VoidCallback onTap;

  const ChildSelectorChip({
    super.key,
    required this.name,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? kHoppoOrange : kSurface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? kHoppoOrange : const Color(0xFFE0E0E0),
          ),
        ),
        child: Text(
          name,
          style: TextStyle(
            fontFamily: 'Outfit',
            fontWeight: FontWeight.w600,
            fontSize: 13,
            color: selected ? Colors.white : kTextMid,
          ),
        ),
      ),
    );
  }
}

class SOSButton extends StatelessWidget {
  final VoidCallback onPressed;
  const SOSButton({super.key, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: onPressed,
      child: Container(
        width: 64,
        height: 64,
        decoration: const BoxDecoration(
          color: kRed,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(color: Color(0x44E74C3C), blurRadius: 12, spreadRadius: 4),
          ],
        ),
        child: const Center(
          child: Text(
            'SOS',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Outfit',
              fontWeight: FontWeight.w800,
              fontSize: 16,
              letterSpacing: 1,
            ),
          ),
        ),
      ),
    );
  }
}

class AlertBadge extends StatelessWidget {
  final int count;
  final Widget child;
  const AlertBadge({super.key, required this.count, required this.child});

  @override
  Widget build(BuildContext context) {
    if (count == 0) return child;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        child,
        Positioned(
          top: -4,
          right: -4,
          child: Container(
            padding: const EdgeInsets.all(3),
            decoration: const BoxDecoration(
              color: kRed,
              shape: BoxShape.circle,
            ),
            child: Text(
              count > 9 ? '9+' : '$count',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 9,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class StatusPill extends StatelessWidget {
  final String label;
  final Color color;
  final Color bgColor;

  const StatusPill({
    super.key,
    required this.label,
    required this.color,
    required this.bgColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontFamily: 'Outfit',
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
      ),
    );
  }
}