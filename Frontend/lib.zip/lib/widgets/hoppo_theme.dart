import 'package:flutter/material.dart';

const kHoppoOrange = Color(0xFFC25A3A);
const kHoppoOrangeLight = Color(0xFFF5E8E4);
const kBackground = Color(0xFFF8F8F8);
const kSurface = Colors.white;
const kTextDark = Color(0xFF1A1A1A);
const kTextMid = Color(0xFF6B6B6B);

const kGreen = Color(0xFF27AE60);
const kGreenLight = Color(0xFFE8F8EF);
const kAmber = Color(0xFFF39C12);
const kAmberLight = Color(0xFFFEF6E4);
const kRed = Color(0xFFE74C3C);
const kRedLight = Color(0xFFFDECEB);

ThemeData hoppoTheme() {
  return ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: kHoppoOrange),
    scaffoldBackgroundColor: kBackground,
    fontFamily: 'Outfit',
    appBarTheme: const AppBarTheme(
      backgroundColor: kSurface,
      elevation: 0,
      titleTextStyle: TextStyle(
        fontFamily: 'Outfit',
        color: kTextDark,
        fontSize: 18,
        fontWeight: FontWeight.w700,
      ),
      iconTheme: IconThemeData(color: kTextDark),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: kSurface,
      selectedItemColor: kHoppoOrange,
      unselectedItemColor: kTextMid,
      type: BottomNavigationBarType.fixed,
      selectedLabelStyle: TextStyle(fontFamily: 'Outfit', fontSize: 11, fontWeight: FontWeight.w600),
      unselectedLabelStyle: TextStyle(fontFamily: 'Outfit', fontSize: 11),
    ),
  );
}