import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:hoppo/services/auth/auth_service.dart';
import 'package:hoppo/services/db/database_provider.dart';
import 'package:hoppo/providers/parent_provider.dart';
import 'package:hoppo/views/Register_Login_View.dart';
import 'package:hoppo/views/app_shell.dart';
import 'package:hoppo/views/driver_shell.dart';
import 'package:hoppo/views/pop_view.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'package:hoppo/providers/driver_provider.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DatabaseProvider()),
        ChangeNotifierProvider(create: (_) => ParentProvider()),
        ChangeNotifierProvider(create: (_) => DriverProvider()),
      ],
      child: MaterialApp(
        title: 'Hoppo',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(primarySwatch: Colors.blue),
        home: const _AuthGate(),
      ),
    ),
  );
}

class _AuthGate extends StatelessWidget {
  const _AuthGate();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _Loader();
        }

        final user = snapshot.data;

        if (user == null) {
          return const Register_Login_View();
        }

        final isVerified = AuthService.firebase().currentUser?.isEmailVeified ?? false;
        if (!isVerified) {
          return const VerifyEmailView();
        }

        // Logged in + verified → check role
        return _RoleRouter(uid: user.uid);
      },
    );
  }
}

class _RoleRouter extends StatefulWidget {
  final String uid;
  const _RoleRouter({required this.uid});

  @override
  State<_RoleRouter> createState() => _RoleRouterState();
}

class _RoleRouterState extends State<_RoleRouter> {
  bool _checked = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await context.read<DatabaseProvider>().checkUserFormStatus(widget.uid);
      if (mounted) setState(() => _checked = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_checked) return const _Loader();

    final dbProvider = context.watch<DatabaseProvider>();

    // Role not selected yet → show PopView as a blocking dialog over a blank scaffold
    if (!dbProvider.hasFilledchoice) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: Builder(
          builder: (ctx) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              showDialog(
                context: ctx,
                barrierDismissible: false,
                builder: (_) => const PopView(),
              );
            });
            return const _Loader();
          },
        ),
      );
    }

    // Route based on saved role
    switch (dbProvider.role) {
      case 'parent':
        return const AppShell();
      case 'driver':
        return const DriverShell();
      case 'school':
        // return const SchoolShell();
        return _ComingSoon(role: 'School Admin');
      case 'business':
        // return const BusinessShell();
        return _ComingSoon(role: 'Business / HR');
      case 'rider':
        // return const RiderShell();
        return _ComingSoon(role: 'Adult Rider');
      default:
        // role is null/unknown — force re-selection
        return Scaffold(
          backgroundColor: Colors.white,
          body: Builder(
            builder: (ctx) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                showDialog(
                  context: ctx,
                  barrierDismissible: false,
                  builder: (_) => const PopView(),
                );
              });
              return const _Loader();
            },
          ),
        );
    }
  }
}

class _Loader extends StatelessWidget {
  const _Loader();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(color: Color(0xFFC25A3A)),
      ),
    );
  }
}

// Placeholder for unbuilt role shells
class _ComingSoon extends StatelessWidget {
  final String role;
  const _ComingSoon({required this.role});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.construction_rounded, size: 48, color: Color(0xFFC25A3A)),
            const SizedBox(height: 16),
            Text(
              '$role App',
              style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),
            ),
            const SizedBox(height: 8),
            const Text(
              'Coming soon',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 32),
            TextButton(
              onPressed: () => FirebaseAuth.instance.signOut(),
              child: const Text('Sign out',
                  style: TextStyle(color: Color(0xFFC25A3A))),
            ),
          ],
        ),
      ),
    );
  }
}