import 'package:flutter/material.dart';
import 'database_service.dart';

class DatabaseProvider extends ChangeNotifier {
  final DatabaseService _databaseService = DatabaseService();
  
  bool _hasFilledchoice = false;
  bool _isLoading = false;
  String? _role;
  // Getters to securely expose variables read-only to the UI
  bool get hasFilledchoice => _hasFilledchoice;
  bool get isLoading => _isLoading;
  String? get role => _role;
  // Method to check form status securely
  Future<void> checkUserFormStatus(String uid) async {
    if (uid.isEmpty) return;
    
    _isLoading = true;
    notifyListeners();

    try {
      _hasFilledchoice= await _databaseService.getchoice(uid);
      if(hasFilledchoice){
        _role = await _databaseService.getRole(uid);
      }
    } catch (e) {
      _hasFilledchoice = false;
      _role = null;
      print("Secure Provider Error: $e");
    } finally {
      _isLoading = false;
      notifyListeners(); // Tells UI to rebuild safely
    }
  }

  // Method to update form status securely
  Future<void> completeForm(String uid,String role) async {
    if (uid.isEmpty) return;

    try {
      await _databaseService.savestatus(uid,role);
      _hasFilledchoice = true;
      _role = role;
      notifyListeners();
    } catch (e) {
      print("Secure Provider Write Error: $e");
    }
  }
}