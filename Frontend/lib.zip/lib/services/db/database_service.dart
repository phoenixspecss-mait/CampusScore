import 'package:firebase_database/firebase_database.dart';

class DatabaseService {
  final FirebaseDatabase _db = FirebaseDatabase.instance;

  Future<bool> getchoice(String uid) async {
    try {
      final snapshot = await _db.ref("users/$uid/ischoice").get();
      if (snapshot.exists) return snapshot.value as bool;
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<String?> getRole(String uid) async {
    try {
      final snapshot = await _db.ref("users/$uid/role").get();
      if (snapshot.exists) return snapshot.value as String?;
      return null;
    } catch (e) {
      return null;
    }
  }

  Future<void> savestatus(String uid, String role) async {
    try {
      await _db.ref("users/$uid").update({
        "ischoice": true,
        "role": role,
      });
    } catch (e) {
      // ignore
    }
  }
}