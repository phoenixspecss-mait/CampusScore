class CabLocation {
  final double lat;
  final double lng;
  final DateTime updatedAt;

  CabLocation({
    required this.lat,
    required this.lng,
    required this.updatedAt,
  });

  factory CabLocation.fromMap(Map<dynamic, dynamic> map) {
    return CabLocation(
      lat: (map['lat'] ?? 0.0).toDouble(),
      lng: (map['lng'] ?? 0.0).toDouble(),
      updatedAt: map['updatedAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['updatedAt'])
          : DateTime.now(),
    );
  }
}

class CabModel {
  final String cabId;
  final String driverId;
  final String mode;
  final CabLocation location;
  final double speed;
  final bool routeDeviation;
  final String streamUrl;
  final bool audioEnabled;

  CabModel({
    required this.cabId,
    required this.driverId,
    required this.mode,
    required this.location,
    required this.speed,
    required this.routeDeviation,
    required this.streamUrl,
    required this.audioEnabled,
  });

  factory CabModel.fromMap(String id, Map<dynamic, dynamic> map) {
    return CabModel(
      cabId: id,
      driverId: map['driverId'] ?? '',
      mode: map['mode'] ?? 'school',
      location: CabLocation.fromMap(map['location'] ?? {}),
      speed: (map['speed'] ?? 0.0).toDouble(),
      routeDeviation: map['routeDeviation'] ?? false,
      streamUrl: map['streamUrl'] ?? '',
      audioEnabled: map['audioEnabled'] ?? false,
    );
  }
}