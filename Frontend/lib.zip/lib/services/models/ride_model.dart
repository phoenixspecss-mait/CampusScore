class RideModel {
  final String rideId;
  final String childId;
  final String driverId;
  final String cabId;
  final String status;
  final DateTime? eta;
  final DateTime? startTime;
  final bool boarded;
  final bool deboarded;
  final bool boardingPinVerified;

  RideModel({
    required this.rideId,
    required this.childId,
    required this.driverId,
    required this.cabId,
    required this.status,
    this.eta,
    this.startTime,
    required this.boarded,
    required this.deboarded,
    required this.boardingPinVerified,
  });

  factory RideModel.fromMap(String id, Map<dynamic, dynamic> map) {
    return RideModel(
      rideId: id,
      childId: map['childId'] ?? '',
      driverId: map['driverId'] ?? '',
      cabId: map['cabId'] ?? '',
      status: map['status'] ?? 'scheduled',
      eta: map['eta'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['eta'])
          : null,
      startTime: map['startTime'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['startTime'])
          : null,
      boarded: map['boarded'] ?? false,
      deboarded: map['deboarded'] ?? false,
      boardingPinVerified: map['boardingPinVerified'] ?? false,
    );
  }
}