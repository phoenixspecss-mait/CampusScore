enum AlertSeverity { green, amber, red }

enum AlertType {
  boarded,
  arrived,
  speedWarning,
  halt,
  routeDeviation,
  sos,
  pinAlert,
}

class AlertModel {
  final String alertId;
  final String childId;
  final String rideId;
  final AlertSeverity severity;
  final AlertType type;
  final String message;
  final DateTime timestamp;
  final bool read;
  final bool acknowledged;

  AlertModel({
    required this.alertId,
    required this.childId,
    required this.rideId,
    required this.severity,
    required this.type,
    required this.message,
    required this.timestamp,
    required this.read,
    required this.acknowledged,
  });

  factory AlertModel.fromMap(String id, Map<dynamic, dynamic> map) {
    return AlertModel(
      alertId: id,
      childId: map['childId'] ?? '',
      rideId: map['rideId'] ?? '',
      severity: _parseSeverity(map['severity']),
      type: _parseType(map['type']),
      message: map['message'] ?? '',
      timestamp: map['timestamp'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['timestamp'])
          : DateTime.now(),
      read: map['read'] ?? false,
      acknowledged: map['acknowledged'] ?? false,
    );
  }

  static AlertSeverity _parseSeverity(String? s) {
    switch (s) {
      case 'amber':
        return AlertSeverity.amber;
      case 'red':
        return AlertSeverity.red;
      default:
        return AlertSeverity.green;
    }
  }

  static AlertType _parseType(String? t) {
    switch (t) {
      case 'boarded':
        return AlertType.boarded;
      case 'arrived':
        return AlertType.arrived;
      case 'speed_warning':
        return AlertType.speedWarning;
      case 'halt':
        return AlertType.halt;
      case 'route_deviation':
        return AlertType.routeDeviation;
      case 'sos':
        return AlertType.sos;
      case 'pin_alert':
        return AlertType.pinAlert;
      default:
        return AlertType.boarded;
    }
  }
}