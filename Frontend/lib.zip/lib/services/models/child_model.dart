class EmergencyContact {
  final String contactId;
  final String name;
  final String phone;
  final String relation;

  EmergencyContact({
    required this.contactId,
    required this.name,
    required this.phone,
    required this.relation,
  });

  factory EmergencyContact.fromMap(String id, Map<dynamic, dynamic> map) {
    return EmergencyContact(
      contactId: id,
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      relation: map['relation'] ?? '',
    );
  }
}

class ChildModel {
  final String childId;
  final String parentUid;
  final String name;
  final String schoolId;
  final String subscriptionId;
  final String boardingPin;
  final List<EmergencyContact> emergencyContacts;

  ChildModel({
    required this.childId,
    required this.parentUid,
    required this.name,
    required this.schoolId,
    required this.subscriptionId,
    required this.boardingPin,
    required this.emergencyContacts,
  });

  factory ChildModel.fromMap(String id, Map<dynamic, dynamic> map) {
    final contacts = <EmergencyContact>[];
    if (map['emergencyContacts'] != null) {
      (map['emergencyContacts'] as Map).forEach((k, v) {
        contacts.add(EmergencyContact.fromMap(k, v));
      });
    }
    return ChildModel(
      childId: id,
      parentUid: map['parentUid'] ?? '',
      name: map['name'] ?? '',
      schoolId: map['schoolId'] ?? '',
      subscriptionId: map['subscriptionId'] ?? '',
      boardingPin: map['boardingPin'] ?? '',
      emergencyContacts: contacts,
    );
  }
}