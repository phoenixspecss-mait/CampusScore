import 'package:firebase_database/firebase_database.dart';

class DriverService {
  final _db = FirebaseDatabase.instance.ref();

  Future<void> updateCabLocation(
      String cabId, double lat, double lng, double speed) async {
    await _db.child('hoppo/cabs/$cabId').update({
      'location': {
        'lat': lat,
        'lng': lng,
        'updatedAt': ServerValue.timestamp,
      },
      'speed': speed,
    });
  }

  Future<void> updateCabMode(String cabId, String mode) async {
    await _db.child('hoppo/cabs/$cabId').update({'mode': mode});
  }
  

  Future<void> setRouteDeviation(String cabId, bool deviated) async {
    await _db.child('hoppo/cabs/$cabId').update({'routeDeviation': deviated});
  }

  Future<Map<String, dynamic>?> getCabForDriver(String driverId) async {
    final snap = await _db
        .child('hoppo/cabs')
        .orderByChild('driverId')
        .equalTo(driverId)
        .get();
    final data = snap.value as Map<dynamic, dynamic>?;
    if (data == null) return null;
    String? cabId;
    Map<dynamic, dynamic>? cabData;
    data.forEach((k, v) {
      cabId = k;
      cabData = v;
    });
    if (cabId == null) return null;
    return {'cabId': cabId, ...Map<String, dynamic>.from(cabData!)};
  }

  Stream<List<Map<String, dynamic>>> activeRidesForDriver(String driverId) {
    return _db
        .child('hoppo/rides')
        .orderByChild('driverId')
        .equalTo(driverId)
        .onValue
        .map((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data == null) return [];
      final rides = <Map<String, dynamic>>[];
      data.forEach((k, v) {
        final ride = Map<String, dynamic>.from(v);
        ride['rideId'] = k;
        if (ride['status'] == 'in_progress' ||
            ride['status'] == 'scheduled') {
          rides.add(ride);
        }
      });
      return rides;
    });
  }

  Future<void> verifyBoardingPin(
      String rideId, String parentUid, String childId) async {
    await _db.child('hoppo/rides/$rideId').update({
      'boarded': true,
      'boardingPinVerified': true,
    });
    await _db.child('hoppo/alerts/$parentUid').push().set({
      'childId': childId,
      'rideId': rideId,
      'severity': 'green',
      'type': 'boarded',
      'message': 'Your child has boarded the cab.',
      'timestamp': ServerValue.timestamp,
      'read': false,
      'acknowledged': false,
    });
  }

  Future<void> markDeboarded(
      String rideId, String parentUid, String childId) async {
    await _db.child('hoppo/rides/$rideId').update({
      'deboarded': true,
      'status': 'completed',
    });
    await _db.child('hoppo/alerts/$parentUid').push().set({
      'childId': childId,
      'rideId': rideId,
      'severity': 'green',
      'type': 'arrived',
      'message': 'Your child has arrived safely.',
      'timestamp': ServerValue.timestamp,
      'read': false,
      'acknowledged': false,
    });
  }

  Future<void> reportDetour(
      String rideId, String cabId, String parentUid, String childId) async {
    await _db.child('hoppo/cabs/$cabId').update({'routeDeviation': true});
    await _db.child('hoppo/alerts/$parentUid').push().set({
      'childId': childId,
      'rideId': rideId,
      'severity': 'red',
      'type': 'route_deviation',
      'message': 'Driver has reported a route detour.',
      'timestamp': ServerValue.timestamp,
      'read': false,
      'acknowledged': false,
    });
  }
  Future<void> triggerSos(
    String cabId, String driverUid, List<Map<String, dynamic>> activeRides) async {
  // 1. Mark cab as SOS active
  await _db.child('hoppo/cabs/$cabId').update({
    'sosActive': true,
    'sosTriggeredAt': ServerValue.timestamp,
    'sosTriggeredBy': driverUid,
  });
 
  // 2. Write to hoppo/sos/{cabId} for admin dashboard
  await _db.child('hoppo/sos/$cabId').set({
    'driverUid': driverUid,
    'cabId': cabId,
    'triggeredAt': ServerValue.timestamp,
    'status': 'active',
    'escalationStep': 1,
  });
 
  // 3. Push red SOS alert to every parent in active rides
  for (final ride in activeRides) {
    final parentUid = ride['parentUid'] as String? ?? '';
    final childId = ride['childId'] as String? ?? '';
    final rideId = ride['rideId'] as String? ?? '';
    if (parentUid.isEmpty) continue;
    await _db.child('hoppo/alerts/$parentUid').push().set({
      'childId': childId,
      'rideId': rideId,
      'severity': 'red',
      'type': 'sos',
      'message': 'Your child\'s driver has triggered an SOS. Hoppo admin is responding.',
      'timestamp': ServerValue.timestamp,
      'read': false,
      'acknowledged': false,
    });
  }
}
 
Future<void> cancelSos(String cabId) async {
  await _db.child('hoppo/cabs/$cabId').update({'sosActive': false});
  await _db.child('hoppo/sos/$cabId').update({
    'status': 'cancelled',
    'cancelledAt': ServerValue.timestamp,
  });
}
}