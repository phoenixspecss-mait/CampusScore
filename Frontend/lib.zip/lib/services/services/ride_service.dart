import 'package:firebase_database/firebase_database.dart';
import '../models/ride_model.dart';
import '../models/cab_model.dart';

class RideService {
  final _db = FirebaseDatabase.instance.ref();

  Stream<RideModel?> activeRideForChild(String childId) {
    return _db
        .child('hoppo/rides')
        .orderByChild('childId')
        .equalTo(childId)
        .onValue
        .map((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data == null) return null;
      RideModel? active;
      data.forEach((k, v) {
        final ride = RideModel.fromMap(k, v);
        if (ride.status == 'in_progress') active = ride;
      });
      return active;
    });
  }

  Stream<List<RideModel>> rideHistoryForChild(String childId) {
    return _db
        .child('hoppo/rides')
        .orderByChild('childId')
        .equalTo(childId)
        .onValue
        .map((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data == null) return [];
      final rides = <RideModel>[];
      data.forEach((k, v) {
        final ride = RideModel.fromMap(k, v);
        if (ride.status == 'completed') rides.add(ride);
      });
      rides.sort((a, b) {
        final aTime = a.startTime ?? DateTime(0);
        final bTime = b.startTime ?? DateTime(0);
        return bTime.compareTo(aTime);
      });
      return rides;
    });
  }

  Stream<CabModel?> cabStream(String cabId) {
    return _db.child('hoppo/cabs/$cabId').onValue.map((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data == null) return null;
      return CabModel.fromMap(cabId, data);
    });
  }

  Future<void> triggerSOS(
      String rideId, String parentUid, String childId) async {
    await _db.child('hoppo/alerts/$parentUid').push().set({
      'childId': childId,
      'rideId': rideId,
      'severity': 'red',
      'type': 'sos',
      'message': 'SOS triggered by parent',
      'timestamp': ServerValue.timestamp,
      'read': false,
      'acknowledged': false,
    });
  }
}