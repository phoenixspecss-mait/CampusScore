import 'package:firebase_database/firebase_database.dart';
import '../models/alert_model.dart';

class AlertService {
  final _db = FirebaseDatabase.instance.ref();

  Stream<List<AlertModel>> alertsStream(String parentUid) {
    return _db
        .child('hoppo/alerts/$parentUid')
        .orderByChild('timestamp')
        .onValue
        .map((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data == null) return [];
      final alerts = <AlertModel>[];
      data.forEach((k, v) => alerts.add(AlertModel.fromMap(k, v)));
      alerts.sort((a, b) => b.timestamp.compareTo(a.timestamp));
      return alerts;
    });
  }

  Future<void> markRead(String parentUid, String alertId) async {
    await _db
        .child('hoppo/alerts/$parentUid/$alertId')
        .update({'read': true});
  }

  Future<void> acknowledge(String parentUid, String alertId) async {
    await _db
        .child('hoppo/alerts/$parentUid/$alertId')
        .update({'read': true, 'acknowledged': true});
  }

  Future<void> markAllRead(String parentUid) async {
    final snap =
        await _db.child('hoppo/alerts/$parentUid').get();
    final data = snap.value as Map<dynamic, dynamic>?;
    if (data == null) return;
    final updates = <String, dynamic>{};
    data.forEach((k, _) {
      updates['hoppo/alerts/$parentUid/$k/read'] = true;
    });
    await _db.update(updates);
  }

  int unreadCount(List<AlertModel> alerts) =>
      alerts.where((a) => !a.read).length;

  int unacknowledgedRedCount(List<AlertModel> alerts) =>
      alerts.where((a) => a.severity == AlertSeverity.red && !a.acknowledged).length;
}