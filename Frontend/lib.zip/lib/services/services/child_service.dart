import 'package:firebase_database/firebase_database.dart';
import '../models/child_model.dart';

class ChildService {
  final _db = FirebaseDatabase.instance.ref();

  Stream<List<ChildModel>> childrenStream(String parentUid) {
    return FirebaseDatabase.instance
        .ref()
        .child('hoppo') // Navigates under your database root wrapper
        .child('children')
        .orderByChild(
          'parentUid',
        ) // Essential: Matches the rule's query parameter
        .equalTo(
          parentUid,
        ) 
        .onValue
        .map((event) {
          final Map<dynamic, dynamic>? totalData =
              event.snapshot.value as Map<dynamic, dynamic>?;
          if (totalData == null) return [];

          return totalData.entries
              .map(
                (e) =>
                    ChildModel.fromMap(e.key, e.value as Map<dynamic, dynamic>),
              )
              .toList();
        });
  }

  Future<String> addChild({
    required String parentUid,
    required String name,
    required String schoolId,
    required String boardingPin,
  }) async {
    final ref = _db.child('hoppo/children').push();
    await ref.set({
      'parentUid': parentUid,
      'name': name,
      'schoolId': schoolId,
      'subscriptionId': '',
      'boardingPin': boardingPin,
      'emergencyContacts': {},
    });
    return ref.key!;
  }

  Future<void> updateBoardingPin(String childId, String newPin) async {
    await _db.child('hoppo/children/$childId').update({'boardingPin': newPin});
  }

  Future<void> updateSpeedThreshold(String childId, int kmh) async {
    await _db.child('hoppo/children/$childId').update({'speedThreshold': kmh});
  }

  Future<void> addEmergencyContact(
    String childId,
    String name,
    String phone,
    String relation,
  ) async {
    await _db.child('hoppo/children/$childId/emergencyContacts').push().set({
      'name': name,
      'phone': phone,
      'relation': relation,
    });
  }

  Future<void> removeEmergencyContact(String childId, String contactId) async {
    await _db
        .child('hoppo/children/$childId/emergencyContacts/$contactId')
        .remove();
  }
}
