import 'package:hoppo/services/auth/auth_user.dart';

abstract class AuthProvider {
  AuthUser? get currentUser;
  Future<AuthUser> logIn({
    required String email,
    required String password
  });
  Future<AuthUser> createUser({
    required String email,
    required String password
  });
  Future<void> initialize();
  Future<void> Logout();
  Future<AuthUser> getupdateduser();
  Future<void> sendEmailVerification();
  Future<AuthUser> signInWithGoogle();
}