import 'package:hoppo/services/auth/auth_exceptions.dart';
import 'package:hoppo/services/auth/auth_provider.dart';
import 'package:hoppo/services/auth/auth_user.dart';
import 'package:hoppo/services/auth/firebase_auth_provider.dart';

class AuthService implements AuthProvider {
  final AuthProvider provider;
  const AuthService(this.provider);

factory AuthService.firebase() => AuthService(FirebaseAuthProvider());

  @override
  Future<void> Logout() => provider.Logout();

  @override
  Future<AuthUser> createUser({
    required String email,
    required String password,
  }) => provider.createUser(email: email, password: password);

  @override
  AuthUser? get currentUser => provider.currentUser;
@override
Future<AuthUser> signInWithGoogle() => provider.signInWithGoogle();
  @override
  Future<AuthUser> logIn({
    required String email, 
    required String password,
    }) => provider.logIn(email: email, password: password);

  @override
  Future<void> sendEmailVerification() => provider.sendEmailVerification();
  
  @override
  Future<void> initialize() => provider.initialize();

  @override
  Future<AuthUser> getupdateduser() => provider.getupdateduser();
}
