import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/models/ride_model.dart';
import '../services/models/cab_model.dart';
import '../services/models/alert_model.dart';
import '../services/models/child_model.dart';
import '../services/services/ride_service.dart';
import '../services/services/alert_service.dart';
import '../services/services/child_service.dart';

class ParentProvider extends ChangeNotifier {
  final _rideService = RideService();
  final _alertService = AlertService();
  final _childService = ChildService();

  List<ChildModel> children = [];
  ChildModel? selectedChild;
  RideModel? activeRide;
  CabModel? activeCab;
  List<AlertModel> alerts = [];
  List<RideModel> rideHistory = [];
  bool audioEnabled = false;
  bool talkbackActive = false;
  bool loading = true;

  StreamSubscription? _childrenSub;
  StreamSubscription? _rideSub;
  StreamSubscription? _cabSub;
  StreamSubscription? _alertSub;
  StreamSubscription? _historySub;

  String get parentUid => FirebaseAuth.instance.currentUser?.uid ?? '';

  void init() {
    loading = true;
    notifyListeners();

    _childrenSub = _childService.childrenStream(parentUid).listen((list) {
      children = list;
      if (selectedChild == null && list.isNotEmpty) {
        selectChild(list.first);
      }
      loading = false;
      notifyListeners();
    });

    _alertSub = _alertService.alertsStream(parentUid).listen((list) {
      alerts = list;
      notifyListeners();
    });
  }

  void selectChild(ChildModel child) {
    selectedChild = child;
    _rideSub?.cancel();
    _cabSub?.cancel();
    _historySub?.cancel();

    _rideSub = _rideService.activeRideForChild(child.childId).listen((ride) {
      activeRide = ride;
      if (ride != null) {
        _cabSub = _rideService.cabStream(ride.cabId).listen((cab) {
          activeCab = cab;
          notifyListeners();
        });
      } else {
        activeCab = null;
      }
      notifyListeners();
    });

    _historySub =
        _rideService.rideHistoryForChild(child.childId).listen((history) {
      rideHistory = history;
      notifyListeners();
    });
  }

  Future<void> addChild({
    required String name,
    required String schoolId,
    required String boardingPin,
  }) async {
    await _childService.addChild(
      parentUid: parentUid,
      name: name,
      schoolId: schoolId,
      boardingPin: boardingPin,
    );
  }

  Future<void> updateBoardingPin(String childId, String newPin) async {
    await _childService.updateBoardingPin(childId, newPin);
  }

  int get unreadCount => _alertService.unreadCount(alerts);
  int get redAlertCount => _alertService.unacknowledgedRedCount(alerts);

  List<AlertModel> get redAlerts =>
      alerts.where((a) => a.severity == AlertSeverity.red).toList();
  List<AlertModel> get amberAlerts =>
      alerts.where((a) => a.severity == AlertSeverity.amber).toList();
  List<AlertModel> get greenAlerts =>
      alerts.where((a) => a.severity == AlertSeverity.green).toList();

  Future<void> markAlertRead(String alertId) async {
    await _alertService.markRead(parentUid, alertId);
  }

  Future<void> acknowledgeAlert(String alertId) async {
    await _alertService.acknowledge(parentUid, alertId);
  }

  Future<void> markAllRead() async {
    await _alertService.markAllRead(parentUid);
  }

  Future<void> triggerSOS() async {
    if (activeRide == null || selectedChild == null) return;
    await _rideService.triggerSOS(
        activeRide!.rideId, parentUid, selectedChild!.childId);
  }

  void toggleAudio() {
    audioEnabled = !audioEnabled;
    notifyListeners();
  }

  void toggleTalkback() {
    talkbackActive = !talkbackActive;
    notifyListeners();
  }

  @override
  void dispose() {
    _childrenSub?.cancel();
    _rideSub?.cancel();
    _cabSub?.cancel();
    _alertSub?.cancel();
    _historySub?.cancel();
    super.dispose();
  }
}