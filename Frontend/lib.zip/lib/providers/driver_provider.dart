import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/services/driver_service.dart';

class DriverProvider extends ChangeNotifier {
  final _driverService = DriverService();

  String? cabId;
  String mode = 'school';
  List<Map<String, dynamic>> activeRides = [];
  bool loading = true;

  StreamSubscription? _ridesSub;

  String get driverUid => FirebaseAuth.instance.currentUser?.uid ?? '';

  Future<void> init() async {
    loading = true;
    notifyListeners();

    final cabData = await _driverService.getCabForDriver(driverUid);
    if (cabData != null) {
      cabId = cabData['cabId'];
      mode = cabData['mode'] ?? 'school';
    }

    _ridesSub =
        _driverService.activeRidesForDriver(driverUid).listen((rides) {
      activeRides = rides;
      loading = false;
      notifyListeners();
    });
  }

  Future<void> switchMode(String newMode) async {
    mode = newMode;
    notifyListeners();
    if (cabId != null) {
      await _driverService.updateCabMode(cabId!, newMode);
    }
  }

  Future<void> updateLocation(double lat, double lng, double speed) async {
    if (cabId == null) return;
    await _driverService.updateCabLocation(cabId!, lat, lng, speed);
  }

  Future<void> verifyPin(
      String rideId, String parentUid, String childId) async {
    await _driverService.verifyBoardingPin(rideId, parentUid, childId);
    notifyListeners();
  }

  Future<void> markArrived(
      String rideId, String parentUid, String childId) async {
    await _driverService.markDeboarded(rideId, parentUid, childId);
    notifyListeners();
  }

  Future<void> reportDetour(
      String rideId, String parentUid, String childId) async {
    if (cabId == null) return;
    await _driverService.reportDetour(
        rideId, cabId!, parentUid, childId);
    notifyListeners();
  }

  @override
  void dispose() {
    _ridesSub?.cancel();
    super.dispose();
  }
  Future<void> triggerSos() async {
  if (cabId == null) return;
  await _driverService.triggerSos(cabId!, driverUid, activeRides);
  notifyListeners();
}
 
Future<void> cancelSos() async {
  if (cabId == null) return;
  await _driverService.cancelSos(cabId!);
  notifyListeners();
}
}